// src/components/ProductCard/index.tsx
import React, { useState } from "react";
import { View, Text, Image, TouchableOpacity } from "react-native";
import styles from "./styles";
import type { Product } from "../../api/products";

type Props = {
  product: Product;
  onPress: () => void;
};

export default function ProductCard({ product, onPress }: Props) {
  const [imageError, setImageError] = useState(false);

  // Garante que sempre teremos um número para trabalhar
  const precoNumber =
    typeof product.preco === "number"
      ? product.preco
      : Number(product.preco ?? 0);

  return (
    <TouchableOpacity style={styles.container} onPress={onPress}>
      {!imageError ? (
        <Image
          source={{ uri: product.foto }}
          style={styles.image}
          onError={() => {
            console.log("Erro ao carregar imagem:", product.foto);
            setImageError(true);
          }}
        />
      ) : (
        <View
          style={[
            styles.image,
            {
              backgroundColor: "#ddd",
              justifyContent: "center",
              alignItems: "center",
            },
          ]}
        >
          <Text style={{ color: "#999" }}>Sem imagem</Text>
        </View>
      )}

      <Text numberOfLines={1} style={styles.title}>
        {product.nome}
      </Text>

      <Text style={styles.price}>
        R$ {precoNumber.toFixed(2).replace(".", ",")}
      </Text>
    </TouchableOpacity>
  );
}
